# Add Third Party Integrations

Collaborators: Anonymous, Anonymous, Anonymous
Department: Engineering
Owner: Anonymous
Priority: P2
Status: Complete 🙌
Themes: 🏗 Scale Our Platform
Timeline: August 17, 2019 → August 5, 2019
Type: Epic ⛰️

<aside>
💡 Epics are a way to group tasks and plan on a macro level. You *could* add additional context below, but we've chosen to keep details inside the associated tasks.

</aside>