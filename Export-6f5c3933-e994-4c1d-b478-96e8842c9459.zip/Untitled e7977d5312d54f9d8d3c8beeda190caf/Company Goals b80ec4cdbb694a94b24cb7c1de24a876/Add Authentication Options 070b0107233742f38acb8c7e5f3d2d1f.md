# Add Authentication Options

Collaborators: Anonymous, Anonymous, Anonymous
Department: Engineering
Owner: Anonymous
Priority: P3
Status: In Progress
Themes: 🌱 Product Foundations
Timeline: August 15, 2019 → August 2, 2019
Type: Epic ⛰️

<aside>
💡 Epics are a way to group tasks and plan on a macro level. You *could* add additional context below, but we've chosen to keep details inside the associated tasks.

</aside>