# Improve Product Onboarding

Collaborators: Anonymous
Department: Engineering
Owner: Anonymous
Priority: P3
Sprint: Sprint 20
Status: Complete 🙌
Themes: 👥 Increase Top of Funnel
Type: Bug 🐞

# Description

- ...
- ...

# Steps to reproduce

1. ...
2. ...

# Screenshots

# Recommendations

- ...
- ...