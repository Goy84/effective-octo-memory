# Hit $500k in APAC Bookings

Collaborators: Anonymous
Department: Sales
Owner: Anonymous
Priority: P2
Themes: 💰 Hit Revenue Targets