# Improve App Performance

Collaborators: Anonymous
Department: Engineering
Owner: Anonymous
Priority: P1 🔥
Status: In Progress
Themes: 🌱 Product Foundations
Timeline: August 27, 2019 → August 19, 2019
Type: Epic ⛰️

Performance 

<aside>
💡 Epics are a way to group tasks and plan on a macro level. You *could* add additional context below, but we've chosen to keep details inside the associated tasks.

</aside>